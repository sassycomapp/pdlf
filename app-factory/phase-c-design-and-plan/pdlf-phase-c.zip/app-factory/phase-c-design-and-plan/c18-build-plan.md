---
title: "c18-build-plan"
doc-id: "mb-1d6a836c"
updated: "2026-10-20"
---

## From `pdlf-build-plan.md`: step entry

### Phase C — Design and Plan

Ends with the gates `concept-locked` (Step 21) and `wireframes-approved` (Step 26).

#### Step 18: Pull to local

**Must achieve:** The code repository is pulled to local after the tables are built.

**Carried out by:** The developer, by hand.

**Skills.** Every skill's output is used by the step named after the arrow.
- `wizard` (Matt Pocock): the developer's pull instructions → the local repository the next step reads.

**Shared procedure.** Steps 18, 30 and 33 run this one procedure: the developer pulls App 1's repository to local after work in the Anvil editor; the agent checks that the change it expects is present and stops with a deviation if not. Steps 30 and 33 refer to this step's procedure and do not repeat it.

**Testing:** the expected change is present locally. **Layers with no skill:** all others; the step only moves code.

**Carried over from the old workflow** (to be checked against the step file, then removed):

1. Query GBrain — Context relevant to codebase state
2. Pull Anvil-connected code repo to local — Updated schema from Step 17
3. Verify local repo updated — STOP if schema not present
4. Write Step 18 ledger row — `completed_at`
5. Generate Step Receipt — `<project-library>/pdlf/outputs/step-18-receipt.md`
6. Apply BFT — None
7. Follow execution sequence — Housekeeping, stop, wait for continue

## From `pdlf-phase-b-review.md`: finding 4.7

**4.7 Fit for purpose before thoroughness.** For each step, ask whether it earns its place. Phase C has three near-identical "pull to local" steps (18, 30 and 33): one shared procedure may serve all three. For each review, ask what only it covers, so that the developer is never asked the same question twice.

## From `pol-anvil-platform.md`: pull to local

| Pull | After |
|---|---|
| Step 18 | Data tables created in Anvil at Step 17. |
